let albumArray = []
fetchContent("/albums.json").then((data) => {
    albumArray = data;  
})

function myFunction(genreName) {
    console.log(genreName);

    let newDiv = document.createElement("div");
    newDiv.setAttribute("id", "albumDiv");
    for (let i = 0; i < albumArray.length; i++) {
        if(albumArray[i].genre == genreName) {
            const para = document.createElement("p");
            const node = document.createTextNode(albumArray[i].albumName);
            para.appendChild(node);
            newDiv.appendChild(para);
        }
    }
    document.getElementById("albumDiv").replaceWith(newDiv);
}

//Magi - det taler vi om senere!!
async function fetchContent(url) {
    let request = await fetch(url);
    let json = await request.json();
    return json;
}